// ==========================================================================
// Project:   Contacts.groupsController Unit Test
// Copyright: @2013 My Company, Inc.
// ==========================================================================
/*globals Contacts module test ok equals same stop start */

module("Contacts.groupsController");

// TODO: Replace with real unit test for Contacts.groupsController
test("test description", function() {
  var expected = "test";
  var result   = "test";
  equals(result, expected, "test should equal test");
});

